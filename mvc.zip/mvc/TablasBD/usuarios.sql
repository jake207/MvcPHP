CREATE TABLE usuarios (
    matricula CHAR(10) PRIMARY KEY AUTO,
    perfil MEDIUMBLOB,
    nombre VARCHAR(25) NOT NULL,
    apellido VARCHAR(45) NOT NULL,
    edad INT CHECK (edad >= 17 AND edad <= 75),
    carrera ENUM('sistemas', 'pedagogia', 'turismo', 'psicologia') NOT NULL,
    telefono INT NOT NULL,
    turno ENUM('matutino', 'matutino b', 'vespertino', 'diurno') NOT NULL,
    grupo VARCHAR(45) NOT NULL,
    genero ENUM('hombre', 'mujer', 'otro') NOT NULL
);


DELIMITER //
CREATE TRIGGER set_matricula BEFORE INSERT ON usuarios
FOR EACH ROW
BEGIN
    SET NEW.matricula = CONCAT('2222', LPAD(FLOOR(RAND() * 999999), 6, '0'));
END //
DELIMITER ;

CREATE TABLE alumnos (
    matricula CHAR(10) PRIMARY KEY,
    nombre VARCHAR(25) NOT NULL,
    apellido VARCHAR(45) NOT NULL,
    correo VARCHAR(50) NOT NULL,
    contrasenia VARCHAR(50) NOT NULL
);

