<?php include("db_quejas.php"); ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilo_quejas.css">
        <title>Quejas y Sugerencias</title>
</head>
<?php require 'views/navbar.php';?>    

<body>


<CENTER>
<h1 class= "quejas"><span>Q</span><span>U</span><span>E</span><span>J</span><span>A</span><span></span><span>S</span> <span>Y
 </span><span>S</span><span>U</span><span></span><span>G</span><span>E</span><span>R</span><span></span><span>E</span><span></span><span>N</span><span></span><span>C</span><span></span><span>I</span><span>
</span><span>A</span><span></span><span>S</span><span></span><span>!</span></h1>


<TABLE CELLSPACING=8 CELLPADDING=1 WIDTH=400 BORDER=0 STYLE="border:1px solid black; border-spacing:1; border-radius:25px;">
<TR>
<TD BGCOLOR="#e3f2ff">
<CENTER>
<SPAN STYLE="font-size:17px;font-family:Tahoma;color:black;font-weight:bold"> Quejas de la comunidad UNIMEXITARIA
</SPAN>
</CENTER>
</TD>
</TR>

<TR>
<TD HEIGHT=1 BGCOLOR=black>
</TD>
</TR>

<TR>
<TD BGCOLOR="#e3f2ff">
<SPAN STYLE="font-size:11px;font-family:Tahoma;color:black;">

<CENTER> 
<form action="guardar_quejas.php" method="POST">
Asunto : <br><br><INPUT TYPE="text" NAME="asunto" SIZE=20 MAXLENGTH=20> 
<BR> 

Comentario: <br><br> <textarea name="queja_sugerencia" rows="8" size=28 placeholder="ESCRIBE AQUÍ" ></textarea>
<BR> 


<button NAME = "save_quejas_sugerencias" TYPE="submit" CLASS="boton">
  <div class="svg-wrapper-1">
    <div class="svg-wrapper">
      <svg height="24" width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 0h24v24H0z" fill="none"></path>
        <path d="M1.946 9.315c-.522-.174-.527-.455.01-.634l19.087-6.362c.529-.176.832.12.684.638l-5.454 19.086c-.15.529-.455.547-.679.045L12 14l6-8-8 6-8.054-2.685z" fill="currentColor"></path>
      </svg>
    </div>
  </div>
  <span >Enviar Queja</span>
</button>
</CENTER>
</FORM>
</SPAN>
</TD>
</TR>
</TABLE>
</CENTER>
<?php require 'views/footer.php';?>    

</body>
</html>
