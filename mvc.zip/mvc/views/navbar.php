<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edhe">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu desplegable</title>
    <link rel="stylesheet" href="<?php echo constant('URL'); ?>public/css/navbar.css">
</head>
<body>
    <nav class="nav">
        <ul class="list">
            <li class="list_item">
                <div class="list_button">
                 <img src="<?php echo constant('URL'); ?>public/assets/ini.svg" class="list_img">
                 <a href="<?php echo constant('URL'); ?>inicio" class="nav_link">Inicio</a>
                </div>
            </li>
                    <li class="list_item">
                        <div class="list_button">
                         <img src="<?php echo constant('URL'); ?>public/assets/usuario.svg" class="list_img">
                         <a href="<?php echo constant('URL'); ?>consulta" class="nav_link">Alumno</a>
                        </div>
                    </li>
                    <li class="list_item">
                        <div class="list_button">
                         <img src="<?php echo constant('URL'); ?>public/assets/usuario.svg" class="list_img">
                         <a href="<?php echo constant('URL'); ?>consulta" class="nav_link">Citas</a>
                        </div>
                    </li>
            <li class="list_item">
                <div class="list_button list_button--click">
                 <img src="<?php echo constant('URL'); ?>public/assets/lib.svg" class="list_img">
                 <a href="<?php echo constant('URL'); ?>libros" class="nav_link">Solicitud de Libros</a>   
                </div>
            </li>

            <li class="list_item">
                <div class="list_button">
                 <img src="<?php echo constant('URL'); ?>public/assets/histori.svg" class="list_img">
                 <a href="<?php echo constant('URL'); ?>historial" class="nav_link">Historial Academico</a>
                </div>
            </li>
            <li class="list_item">
                <div class="list_button">
                 <img src="<?php echo constant('URL'); ?>public/assets/papeles.svg" class="list_img">
                 <a href="#" class="nav_link">Solicitud de Papeles</a>
                </div>
            </li>
            <li class="list_item">
                <div class="list_button">
                 <img src="<?php echo constant('URL'); ?>public/assets/cuenta.svg" class="list_img">
                 <a href="#" class="nav_link">Estado de Cuenta</a>
                </div>
            </li>
            <li class="list_item">
                <div class="list_button">
                 <img src="<?php echo constant('URL'); ?>public/assets/quejas.svg" class="list_img">
                 <a href="<?php echo constant('URL');?>quejas" class="nav_link">Quejas y Sugerencias</a>
                </div>
            </li>
            <li class="list_item">
                <div class="list_button">
                 <img src="<?php echo constant('URL');?>public/assets/salir.svg" class="list_img">
                 <a href="<?php echo constant('URL'); ?>" class="nav_link">Salir</a>
                </div>
            </li>
            
        </ul>
    </nav>

    
</body>
</html>