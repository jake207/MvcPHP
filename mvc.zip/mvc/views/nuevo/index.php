<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Document</title>
</head>
<body>
<?php require 'views/navbar.php';?>    


<div id="main">


<div class ="titulo">
    <h1 class="center">INSCRIPCION1 </h1>
    </div>
 <div class="center"><?php echo $this->mensaje;?></div>
    <form action="<?php echo constant('URL')?>nuevo/registrarAlumno" method="POST">
        
        <img class="image" src="<?php echo constant('URL'); ?>public/image/usuario-de-perfil.png" alt="wapo">
        <input type="file" name="perfil" id="perfil" required>        
       
        <label class=" texto" for="nombre">Nombre</label>
        <input class="tb" type="text" name="nombre" id="nombre" required>        
       
        <label class=" texto" for="apellido">Apellido</label>
        <input class="tb" type="text" name="apellido" id="apellido" required>        
       
        <label class=" texto" for="">Edad</label>
        <input class="tb" type="text" name="edad" id="edad" required>        

        <select name="carrera" id="carrera" required>
            <option value="sistemas">sistemas</option>
            <option value="pedagogia">pedagogia</option>
            <option value="turismo">turismo</option>
            <option value="psicologia">psicologia</option>
        </select>       
      

        <label class=" texto" for="">Numero celular</label>
        <input class="tb" type="text" name="telefono" id="telefono" required>              
       
        <select name="turno" id="turno" required>
            <option value="matutino">matutino</option>
            <option value="matutino b">matutino b</option>
            <option value="vespertino">vespertino</option>
            <option value="diurno">diurno</option>
        </select>       
      
        <label class=" texto" for="">Grupo</label>
        <input class="tb" type="text" name="grupo" id="grupo" required>        

        <select name="genero" id="genero" required>
             <option value="hombre">Hombre</option>
              <option value="mujer">Mujer</option>
             <option value="otro">Otro</option>
        </select>

    <input type="submit" value="INSCRIBIR">


</form>

</div>
<?php require 'views/footer.php';?>    
</body>
</html>