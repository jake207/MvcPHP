<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="shortcut icon" href="img/icon.ico" type="image/x-icon">
    <script src="script.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion</title>
</head>

<body>
<div class="center"><?php echo $this->mensaje;?></div>

    <form action="<?php echo constant('URL')?>main/ingresar" method="POST">       
        <img src="img/LogoUnimex.png" alt=""> </a> 
        <input type="email" id="correo" name="correo" placeholder="CORREO ELECTRONICO" required>
        <input type="password"  id="contrasenia" name="contrasenia" placeholder="CONTRASEÑA" required>
        <input type="submit" class="btn" value="INGRESAR">
    </form>



</body>
</html>