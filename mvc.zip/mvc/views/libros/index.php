<!DOCTYPE html>

<html>
<head>
  <title>Selección de Libros</title>
  <link rel="stylesheet" href="<?php echo constant('URL'); ?>public/css/libros.css">
  
</head>
<?php require 'views/navbar.php';?>    

<body>
<center>
  <div class="container">
  
    <h1>Selecciona tus libros</h1>
    


    <form action="procesar.php" method="post">
    

      <input type="checkbox" name="libros[]" value="George Orwell 1984" id="George Orwell 1984">George Orwell "1984"<br>
      <br><img src="<?php echo constant('URL'); ?>public/image/libros/1984.jpg"><br>
      <p>
      <input type="checkbox" name="libros[]" value="Gabriel Garcia Marquez CIEN AÑOS DE SOLEDAD" id="Gabriel Garcia Marquez CIEN AÑOS DE SOLEDAD">Gabriel Garcia Marquez "CIEN AÑOS DE SOLEDAD"<br>
      <br><img src="<?php echo constant('URL'); ?>public/image/libros/100.jpg"><br>
      <p>
      <input type="checkbox" name="libros[]" value="F. Scott Fitzgerald EL GRAN GATSBY" id="F. Scott Fitzgerald EL GRAN GATSBY">F. Scott Fitzgerald "EL GRAN GATSBY"<br>
      <br><img src="<?php echo constant('URL'); ?>public/image/libros/gat.jpg"><br>
      <p>
      <input type="checkbox" name="libros[]" value="Jane Austen ORGULLO  Y PREJUICIO" id="Jane Austen ORGULLO  Y PREJUICIO">Jane Austen "ORGULLO  Y PREJUICIO"<br>
      <br><img src="<?php echo constant('URL'); ?>public/image/libros/orgullo.jpg"><br>
      <p>
      <input type="checkbox" name="libros[]" value="Miguel de Cervantes DON QUIJOTE DE LA MANCHA" id="Miguel de Cervantes DON QUIJOTE DE LA MANCHA">Miguel de Cervantes "DON QUIJOTE DE LA MANCHA"<br>
      <br><img src="<?php echo constant('URL'); ?>public/image/libros/dq.jpg"><br>
      <p>

      <input type="submit" value="Enviar Solicitud">
    
    
    </form>
    
    
  </div>
  
  </center>
</body>
</html>
