<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php require 'views/navbar.php';?>    
<div id="main">
    <h1 class="center">Seccion de Consulta</h1>
    <div id="respuesta" class="center"></div>
    <table>
        <thead>
            <tr>
                <th>id</th>
                <th>cuatrimestre</th>
                <th>materia</th>
                <th>pp</th>
                <th>sp</th>
                <th>ef</th>
                <th>calificacion</th>
                <th>faltas</th>
                
            </tr>
        </thead>
        <tbody id="tbody-alumnos">
        <?php 
        include_once 'models/historial.php';
        foreach($this->historiala as $row){
            $historial = new Historial();
            $historial = $row;

         
        ?>
            <tr id="fila-<?php echo $historial->id;?>">
                <td><?php echo $historial->id;?></td>
                <td><?php echo $historial->cuatrimestre;?></td>
                <td><?php echo $historial->materia;?></td>
                <td><?php echo $historial->pp;?></td>
                <td><?php echo $historial->sp;?></td>
                <td><?php echo $historial->ef;?></td>
                <td><?php echo $historial->calificacion;?></td>
                <td><?php echo $historial->faltas;?></td>

                
                
                
              <!--  
                <td><a href="<?php echo constant('URL').'consulta/verAlumno/'.$alumno->matricula;?>">Editar</a></td>
                  <td><a href="<?php echo constant('URL').'consulta/eliminarAlumno/'.$alumno->matricula;?>">Eliminar</a>
                    <td><button class="bEliminar" data-matricula="<?php echo $alumno->matricula;?>">Eliminar</button></td></td>-->
            </tr>
            <?php } ?>
        </tbody>
    </table>
    

</div>
<?php require 'views/footer.php';?>    

<script src="<?php echo constant('URL'); ?>public/js/main.js"></script>

</body>
</html>
