<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Document</title>
</head>
<body>
<?php require 'views/navbar.php';?>    


<div id="main">


<div class ="titulo">
    <h1 class="center">Detalle de <?php echo $this->alumno->matricula;?> </h1>
    </div>
 <div class="center"><?php echo $this->mensaje;?></div>
 <form action="<?php echo constant('URL')?>/consulta/actualizarAlumno" method="POST">

        <label class=" texto" for="matricula">Matricula</label>
        <input class="tb" type="text" name="matricula" disabled value="<?php echo $this->alumno->matricula;?> " required>        

        <label class=" texto" for="nombre">Nombre</label>
        <input class="tb" type="text" name="nombre" value="<?php echo $this->alumno->nombre;?>" required>   
        
              
        <label class=" texto" for="apellido">Apellido</label>
        <input class="tb" type="text" name="apellido" value="<?php echo $this->alumno->apellido;?>" required>        
      

    <input type="submit" value="ACTUALIZAR">


</form>
</div>
<?php require 'views/footer.php';?>    
</body>
</html>