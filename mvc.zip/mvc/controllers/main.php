<?php
    class Main extends Controller{

        function __construct(){
            parent::__construct();
            $this->view->mensaje="";

        }
        function render(){
            $this->view->render('main/index');
        }
    

    function ingresar(){
        $correo = $_POST['correo'];
        $contrasenia = $_POST['contrasenia'];

        $alumno = $this->model->verificacion($correo);

        $contra=$alumno->contrasenia;
        echo $contra;
        if ($contrasenia == $contra && $contrasenia!=null) {     
           session_start();
        $_SESSION['id_verAlumno']= $alumno->matricula;
        $_SESSION['validacion']=true;
        ini_set('display_errors', 'off');
        error_reporting(0);
        $this->view->alumno=$alumno;
        $this->view->mensaje ="";
        $this->view->render('inicio/index');

        } else {
            $mensaje="Contraseña Incorrecta";
            $correo = null;
            $contrasenia = null;
            session_start();
            $_SESSION['validacion']=false;
            $this->view->mensaje= $mensaje;
            $this->render();
  
        }
       
    }
    }

?>

