<?php
    class Inicio extends Controller{
        function __construct(){
            parent::__construct();
        }
        function render(){
            $this->view->render('inicio/index');
        }
        function verAlumno($param = null){
            $idAlumno = $param[0];
            $alumno = $this->model->getById($idAlumno);

            session_start();
            $_SESSION['id_verAlumno']= $alumno->matricula;
            $this->view->alumno=$alumno;
            $this->view->mensaje ="";
            $this->view->render('consulta/detalle');
        }
    }

?>
