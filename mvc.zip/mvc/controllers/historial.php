<?php
    class Historial extends Controller{
        function __construct(){
            parent::__construct();
            $this->view->historiala=[];
        }
        function render(){
            $historiala=$this->model->get();
            $this->view->historiala=$historiala;
            $this->view->render('historial/index');
        }

    
        
    }

?>
