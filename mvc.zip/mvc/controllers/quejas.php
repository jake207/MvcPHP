<?php

class Quejas extends Controller{

    function __construct(){
        parent::__construct();

    }
    function render(){
        $this->view->render('quejas/index');
    }
}

?>