<?php
    class Saludos extends Controller{
        function __construct(){
            parent::__construct();
           
            echo "<p>HOLA MAMAHUEVO</p>";
        }
        function render(){
            $this->view->render('saludos/index');
        }
        function saludo(){
            echo"<p>QUE PEDO PERRO</p>";
        }
    }

?>
