<?php
class Error1 extends Controller{
    function __construct(){
        parent::__construct();
        $this->view->mensaje = "Error en la solicitud o no Existe la pagina";
        $this->view->render('error/index');
        
    }
    

}