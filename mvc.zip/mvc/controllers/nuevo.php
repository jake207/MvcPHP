<?php
    class Nuevo extends Controller{
        function __construct(){
            parent::__construct();
            $this->view->mensaje="";
        }
        function render(){
            $this->view->render('nuevo/index');
        }

    function registrarAlumno(){
        $perfil = $_POST['perfil'];
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $edad = $_POST['edad'];
        $carrera = $_POST['carrera'];
        $telefono = $_POST['telefono'];
        $turno = $_POST['turno'];
        $grupo = $_POST['grupo'];
        $genero= $_POST['genero'];
        $mensaje="";
        if($this->model->insert(['perfil'=>$perfil, 'nombre'=>$nombre, 'apellido'=>$apellido, 'edad'=>$edad,'carrera'=>$carrera, 'telefono'=>$telefono, 'turno'=>$turno, 'grupo'=>$grupo, 'genero'=>$genero])){
            $mensaje= "Nuevo Alumno Creado";
        }else{
            $mensaje="La matricula ya existe";
    }
        $this->view->mensaje= $mensaje;
        $this->render();
    }
    }
?>
