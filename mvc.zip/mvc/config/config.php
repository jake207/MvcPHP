<?php
define('URL','http://localhost/php/mvc/');
define('HOST','localhost');
define('DB','mvc');
define('USER','root');
define('PASSWORD','');
define('CHARSET','utf8mb4');
?>