<?php

class App{

    //__construct sirve para que el metodo inicie por defecto
    function __construct(){
       
        //Obtengo el valor de la url
        $url = isset($_GET['url']) ? $_GET['url']:null;   
        //rtrim nos ayuda a eliminar "///////7" extras que pueda tener nuestra url
        $url = rtrim($url, '/');
        //La funcion explode nos ayuda a separar en partes la cadena, hay que indicar que signo lo separara
        $url = explode('/', $url);
        //Var Dump nos ayuda a imprimir lo valores que han sido separados y los muestra en forma de vector
        var_dump($url);

        ini_set('display_errors', 'off');
        error_reporting(0);

            if(empty($url[0])){
                session_start();
                $_SESSION['validacion']=false;
                $archivoController='controllers/main.php';
                require_once $archivoController;
                $controller = new Main();
                $controller->loadModel('main');            
                $controller->render();
              
            }else{

        
                 
                $archivoController='controllers/'.$url[0].'.php';
                //SI LA CLASE EXISTE REALIZA EL PROCESO
                if(file_exists($archivoController) ){
                    session_start();
                    echo "fadsf";
                    //AQUI LLAMA A LA VARIABLE QUE TIENE UNA CLASE
                        if($_SESSION['validacion']==true){
                            require_once $archivoController;
                            //LA VARIABLE CONTROLLER AGARRA EL PRIMER VALOR DE LA URL
                            $controller = new $url[0];
                            $controller->loadModel($url[0]);
                            // numero de elementos del arreglo
                            $nparam = sizeof($url);
                
                
                
                            if($nparam > 1){
                                if(method_exists($controller, $url[1])){
                                    if($nparam>2){
                                        $param = [];
                                        for($i = 2; $i<$nparam; $i++){
                                            array_push($param, $url[$i]);
                                       }
                                        $controller->{$url[1]}($param);
                                    }else{
                                        $controller->{$url[1]}();
                                    }
                                }else{
                                    require_once 'controllers/error.php';
                                    $controller = new Error1();
                                }
                            }else{
                                $controller->render();
                            }
                
                
                            
                        }else{

                            $archivoController='controllers/main.php';
                            require_once $archivoController;
                            $controller = new Main();
                            $controller->loadModel('main');
                            $nparam = sizeof($url);

                            if($nparam > 1){
                                if(method_exists($controller, $url[1])){
                                $controller->{$url[1]}();
                                echo "adios";
                            }else{
                                require_once 'controllers/error.php';
                                $controller = new Error1();
                            }
                            }else{
                                $controller->render();
                                echo "holamunod";
                            }
                        }
                  
           
                }    else{
                    require_once 'controllers/error.php';
                    $controller = new Error1();
                }
            }
             
    }
}

?>