<?php

class QuejasModel extends Model{

    public function __construct(){
        parent::__construct();
    }
  
       
    }


?>