<?php
include_once 'models/alumno.php';

class MainModel extends Model{

    public function __construct(){
        parent::__construct();
    }

    public function verificacion($id){
            $item = new Alumno();
    
                $query = $this->db->connect()->prepare("SELECT*FROM alumnos WHERE correo = :correo");
    
    
            try{
                $query->execute(['correo' => $id]);
                
                while($row = $query->fetch()){
                    $item->matricula = $row['matricula'];
                    $item->nombre = $row['nombre'];
                    $item->apellido = $row['apellido'];
                    $item->correo = $row['correo'];
                    $item->contrasenia = $row['contrasenia'];
                }
                return $item;
                
            }catch(PDOException $e){
                return null;
            }
        }         
}
?>