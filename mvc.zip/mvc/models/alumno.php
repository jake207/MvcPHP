<?php

class Alumno{
    public $correo;
    public $contrasenia;
    public $matricula;
    public $nombre;
    public $apellido;
}

?>