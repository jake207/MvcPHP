<?php

class NuevoModel extends Model{

    public function __construct(){
        parent::__construct();
    }
    public function insert($datos){

        try{
            $query = $this->db->connect()->prepare('INSERT INTO usuarios(perfil, nombre, apellido, edad, carrera,telefono, turno, grupo,genero) values(:perfil,:nombre,:apellido,:edad,:carrera,:telefono,:turno,:grupo,:genero)');
            $query->execute(['perfil'=>$datos['perfil'],'nombre'=>$datos['nombre'],'apellido'=>$datos['apellido'],'edad'=>$datos['edad'],'carrera'=>$datos['carrera'],'telefono'=>$datos['telefono'],'turno'=>$datos['turno'],'grupo'=>$datos['grupo'],'genero'=>$datos['genero']]);
          
            return true;

        }catch(PDOException $e){
                return false;
        }
       
    }
}

?>