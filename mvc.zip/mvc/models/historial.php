<?php

class datosHistorial{
    public $id;
    public $cuatrimestre;
    public $materia;
    public $pp;
    public $sp;
    public $ef;
    public $calificacion;
    public $faltas;
}

?>