<?php
include_once 'models/historial.php';

class HistorialModel extends Model{

    public function __construct(){
        parent::__construct();
    }
    public function get(){
        $items = [];
        try{
            $query = $this->db->connect()->query("SELECT*FROM historial");
            while($row = $query->fetch()){

                $item = new datosHistorial();
                $item->id = $row['id'];
                $item->cuatrimestre =$row['cuatrimestre'];
                $item->materia = $row['materia'];
                $item->pp = $row['pp'];
                $item->sp =$row['sp'];
                $item->ef = $row['ef'];
                $item->calificacion = $row['calificacion'];
                $item->faltas =$row['faltas'];
                
                array_push($items, $item);
            }
            return $items;
        }catch(PDOException $e){
                return [];
        }
       
    }
    public function getById($id){
        $item = new datosHistorial();

            $query = $this->db->connect()->prepare("SELECT*FROM historial WHERE id = :matricula");


        try{
            $query->execute(['matricula' => $id]);
            
            while($row = $query->fetch()){
                $item->matricula = $row['matricula'];
                $item->nombre = $row['nombre'];
                $item->apellido = $row['apellido'];
            }
            return $item;
            
        }catch(PDOException $e){
            return null;
        }
    }

}

?>